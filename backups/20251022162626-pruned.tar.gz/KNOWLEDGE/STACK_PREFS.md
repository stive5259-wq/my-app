Web: Vite + React + TypeScript + Tailwind; run=`pnpm dev`
Python: pyproject + Ruff + PyTest; run=`python -m <pkg>`
