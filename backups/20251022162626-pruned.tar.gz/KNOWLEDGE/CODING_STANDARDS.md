Small modules, deterministic functions, explicit types, fast tests.
