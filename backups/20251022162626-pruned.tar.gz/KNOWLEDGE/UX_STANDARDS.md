Explicit Empty/Loading/Error/Data states; keyboard-first flows; visible latency.
