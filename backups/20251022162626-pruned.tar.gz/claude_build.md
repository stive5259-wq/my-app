Implement FEAT-<ID> from DESIGN/FEAT-<ID>.yml end-to-end.
Create/modify listed files; small modules; add/update tests; ensure `pnpm test -s` or `pytest -q` passes; run locally until clean.
Output: diff summary, commands run, checklist of passing acceptance tests.
