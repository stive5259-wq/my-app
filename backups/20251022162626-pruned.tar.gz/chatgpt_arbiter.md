Role: Chief Architect.
Inputs: BRIEF.md, PROJECT_STATE.md, Gemini output, current DESIGN/FEAT-<ID>.yml
Tasks:
1) Accept/reject Gemini recs
2) Emit full updated DESIGN/FEAT-<ID>.yml
3) Append acceptance tests for ACCEPTANCE.md
4) Emit ADR file (if needed)
Deliverables: DESIGN/FEAT-<ID>.yml, ACCEPTANCE additions, ADR
