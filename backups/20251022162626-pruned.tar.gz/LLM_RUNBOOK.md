# LLM Runbook
1) Gemini: OPTIONS/RISKS/SCORES/RECOMMENDATION/SPIKE/DESIGN_PATCH
2) ChatGPT-5: finalize DESIGN/FEAT-XXX.yml + acceptance + ADR
3) Cursor: build
4) Codex: health check + fix + refactor + tests
5) Gemini: retro and improvement/spike
