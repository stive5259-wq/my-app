Role: Inspector.
1) Run build/dev/test/lint/typecheck; list all errors/warnings with paths
2) Fix plan: P0 crash, P1 correctness, P2 perf/cleanup
3) Implement fixes with minimal diffs; rerun checks
4) Apply one small refactor (≤60 LOC) to reduce future bugs
5) Add/update tests to lock in fixes
Deliver: before/after summary, diffs, commands executed
