Role: Challenger/Coach.
Inputs: latest diffs and test summary.
Tasks: 5-bullet retro, one 60-min DX/UX upgrade, update RISK_REGISTER, optional SPIKE/<name>/README.
